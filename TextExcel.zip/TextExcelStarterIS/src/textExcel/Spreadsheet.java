package textExcel;

public class Spreadsheet implements Grid {
	public static final int ROWS = 20;
	public static final int COLS = 12;
	private Cell[][] arr = new Cell [ROWS][COLS];
	
	public Spreadsheet() {
		for (int i = 0; i < ROWS; i++) {
			for (int k = 0; k < COLS; k++) {
				arr[i][k] = new EmptyCell();
			}
		}
	}

	public String processCommand(String command) {
		if (command.length() == 0) {
			return "";
		}
		else {
			String[]splitting = command.split(" ", 3);
			if (splitting[0].equalsIgnoreCase("clear")){	
				if (splitting.length == 1) {
					for (int i = 0; i < ROWS; i++) {
						for (int k = 0; k < COLS; k++) {
							arr[i][k] = new EmptyCell();
						}
					}
					return getGridText();
				}
				else if (splitting.length == 2) {
					SpreadsheetLocation spot = new SpreadsheetLocation(splitting[1]);
					arr[spot.getRow()][spot.getCol()] = new EmptyCell();
					return getGridText();
				}
			}
			else {
				if (splitting.length == 1) {
					SpreadsheetLocation points = new SpreadsheetLocation(splitting[0]);
					return arr[points.getRow()][points.getCol()].fullCellText();

				}
				else if (splitting.length == 3) {
					if (splitting[2].substring(0,1).equals("\"")){	
						SpreadsheetLocation point = new SpreadsheetLocation(splitting[0]);
						arr[point.getRow()][point.getCol()] = new TextCell(splitting[2].substring(1, splitting[2].length()-1));
						return getGridText();	
					}
					else if (splitting[2].indexOf("(") != -1){
						SpreadsheetLocation point = new SpreadsheetLocation(splitting[0]);
						arr[point.getRow()][point.getCol()] = new FormulaCell(splitting[2], arr);
						return getGridText();
					}
					else if (splitting[2].indexOf("/") != -1){
						SpreadsheetLocation point = new SpreadsheetLocation(splitting[0]);
						arr[point.getRow()][point.getCol()] = new DateCell(splitting[2]);
						return getGridText();
					}
					else {
						SpreadsheetLocation point = new SpreadsheetLocation(splitting[0]);
						arr[point.getRow()][point.getCol()] = new ValueCell(splitting[2]);
						return getGridText();
					}
				}
			}
		}
		return getGridText();
	}

	public int getRows() {
		return ROWS;
	}

	public int getCols() {
		return COLS;
	}

	public Cell getCell(Location loc) {
		Cell position = arr[loc.getRow()][loc.getCol()];
		return position;
	}

	public String getGridText() {
		String last = "   |";
		for (int i = 0; i < COLS; i++) {
			last += (char)('A' + i) + "         |";
		}
		for (int j = 1; j < ROWS + 1; j++) {
			last += "\n" + String.format("%-3d", j);
			for (int k = 0; k < COLS; k++) {
				last += "|" + arr[j-1][k].abbreviatedCellText();
			}
			last += "|";
		}
		last += "\n";
		return last;
	}
}