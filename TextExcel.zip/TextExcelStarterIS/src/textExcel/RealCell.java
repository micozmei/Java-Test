package textExcel;

public class RealCell implements Cell {
	private String input;

	public RealCell (String input) {
		this.input = input;
	}
	public RealCell (double input) {
		this.input = input + "";
	}
	public double getDoubleValue(){
		return Double.parseDouble(input);
	}
	public String abbreviatedCellText(){
		return (input + "          ").substring(0, 10);
	}
	public String fullCellText(){
		return input;
	}
}
