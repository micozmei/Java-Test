package textExcel;

public interface Location {
	int getRow();
	int getCol();
}
