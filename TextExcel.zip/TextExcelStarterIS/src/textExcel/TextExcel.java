package textExcel;
import java.util.Scanner;

public class TextExcel {

	public static void main(String[] args) {
		Grid sheet = new Spreadsheet();
		Scanner console = new Scanner (System.in);
		String s = console.nextLine ();
		while (! s.equalsIgnoreCase("quit")) {
			String z = sheet.processCommand(s);
			System.out.println (z);
			s = console.nextLine();
	    }		
		System.out.println("Bye!");
	}
}
