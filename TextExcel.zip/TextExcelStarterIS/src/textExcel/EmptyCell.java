package textExcel;

public class EmptyCell implements Cell {
	public String abbreviatedCellText = "          ";
	public String fullCellText = "";
	public String abbreviatedCellText() {
		return abbreviatedCellText;
	}
	public String fullCellText() {
		return fullCellText;
	}
}
