package textExcel;

public interface Cell {
	public String abbreviatedCellText();
	public String fullCellText();
}
