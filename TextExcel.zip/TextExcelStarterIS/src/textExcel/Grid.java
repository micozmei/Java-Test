package textExcel;

public interface Grid {
	String processCommand(String command);
	int getRows(); 
	int getCols(); 
	Cell getCell(Location loc);
	String getGridText(); 
}
