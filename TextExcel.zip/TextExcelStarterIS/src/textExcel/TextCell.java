package textExcel;

public class TextCell implements Cell{
	private String text; 
	
	public TextCell(String texting){
			text = texting;
	}
	public String abbreviatedCellText(){
		if(text.length() < 10){
			String pad = text;
			for (int i = pad.length(); i < 10; i++){
				 pad += " ";
			}
			return pad;	
		}
		else{
			return text.substring(0, 10);
		}
	}
	public String fullCellText(){
		return "\"" + text + "\"";	
	}
}