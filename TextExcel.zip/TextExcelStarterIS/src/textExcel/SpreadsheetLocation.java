package textExcel;

public class SpreadsheetLocation implements Location {
	private int getRow;
	private int getCol;
	
	public SpreadsheetLocation(String s) {
		getRow = Integer.parseInt(s.substring(1)) - 1;
		getCol = Character.toUpperCase(s.charAt(0)) - 'A';
	}
	public int getRow(){
		return this.getRow;
	}
	public int getCol(){
		return this.getCol;
	}
}