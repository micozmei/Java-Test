package textExcel;
 
public class FormulaCell extends RealCell {
        private String input;
        private Cell[][] sheet;
       
        public FormulaCell(String input, Cell[][] sheet) {
                super(input);
                this.input = input;
                this.sheet = sheet;
        }
        public String fullCellText() {
                return input;
        }
        public String abbreviatedCellText() {
                String pad = Double.toString(getDoubleValue());
                if (pad.length() < 10) {
                        for (int i = pad.length(); i < 10; i++) {
                                pad += " ";
                        }
                        return pad;
                } else {
                        return pad.substring(0, 10);
                }
        }
        public double format (String s) {
            char character = Character.toUpperCase(s.charAt(0));
            if (character >= 'A' && character <= 'Z') {
                    SpreadsheetLocation newloc = new SpreadsheetLocation(s);
                    Cell loc = sheet[newloc.getRow()][newloc.getCol()];
                    return ((RealCell) loc).getDoubleValue();
            }
            else {
                    return Double.parseDouble(s);
            }
    }
        public double getDoubleValue(){
                String[]splitting = input.split(" ");
                if (splitting[1].equalsIgnoreCase("SUM") || splitting[1].equalsIgnoreCase("AVG")){
                        String start = splitting[2].substring (0,splitting[2].indexOf("-"));
                        String end = splitting[2].substring (splitting[2].indexOf("-") + 1);
                        Location one = new SpreadsheetLocation(start);
                        Location two = new SpreadsheetLocation(end);
                        int row1 = one.getRow();
                        int col1 = one.getCol();
                        int row2 = two.getRow();
                        int col2 = two.getCol();
                        double z = 0;
                        int repeats = 0;
                        for (int i = row1; i <= row2; i++) {
                                for (int k = col1; k <= col2; k++) {
                                         Cell c = sheet[i][k];
                                        z += ((RealCell) c).getDoubleValue();
                                        repeats ++;
                                }
                        }
                        if (splitting[1].equalsIgnoreCase("SUM")){
                                return z;
                        }
                        else {
                                return z/repeats;
                        }      
                }
                else {
                        double z = format(splitting[1]);
                        for (int i = 1; i <= (splitting.length - 3)/2; i++){
                                double x = format(splitting[2*i + 1]);
                                if (splitting[2*i].equals("+")) {
                                        z = z + x;
                                }
                                else if (splitting[2*i].equals("-")) {
                                        z = z - x;
                                }
                                else if (splitting[2*i].equals("*")) {
                                        z = z * x;
                                }
                                else if (splitting[2*i].equals("/")) {
                                        z = z / x;
                                }
                        }
                        return z;
                }
        }
}