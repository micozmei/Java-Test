package textExcel;

public class ValueCell extends RealCell {
	private double value;
	public ValueCell (String input){
		super(input);
		this.value = Double.parseDouble(input);
	}
	public double getDoubleValue(){
		return value;
	}
	public String abbreviatedCellText(){
		return (value + "          ").substring(0, 10);
	}
	public String fullCellText(){
		return value + "";
	}
}
