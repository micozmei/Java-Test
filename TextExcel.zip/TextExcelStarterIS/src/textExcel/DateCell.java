package textExcel;

public class DateCell implements Cell {
	private String input; 
	
	public DateCell(String date){
			input = date;
	}
	public String abbreviatedCellText(){
		if(input.length() < 10){
			String a = input.substring (0, input.indexOf("/") + 1);
			String b = input.substring (a.length(), input.indexOf("/", 3) + 1);
			String c = input.substring (a.length() + b.length());
			if (a.length() == 2){
				a = "0" + a;
			}
			if (b.length() == 2){
				b = "0" + b;
			}
			return a + b + c;
		}
		else {
			return input.substring(0, 10);
		}
	}
	public String fullCellText(){
		return abbreviatedCellText();	
	}
}
