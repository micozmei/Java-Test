package fracCalc;

public class Tests {
	public static void reportResult(String input, String expectedOutput, String actualOutput) {
		if (expectedOutput.equals(actualOutput))
			System.out.println("Test passed: " + input + " -> " + actualOutput);
		else
			System.out.println("Test failed: " + input + " -> " + actualOutput + ", expected " + expectedOutput);
	}
	public static void testProduceAnswer(String input, String expectedOutput) {
		String actualOutput = FracCalc.produceAnswer(input);
		reportResult(input, expectedOutput, actualOutput);
	}
	public static void testGetUnreducedFractionPart(String operand, int expectedNumerator, int expectedDenominator) {
		int actualNumerator = FracCalc.getUnreducedFractionPart(operand, true);
		int actualDenominator = FracCalc.getUnreducedFractionPart(operand,  false);
		String expectedResult = expectedNumerator + "/" + expectedDenominator;
		String actualResult = actualNumerator + "/" + actualDenominator;
		reportResult(operand, expectedResult, actualResult);
	}
	public static void testReduce(int numerator, int denominator, String expectedResult) {
		int actualNumerator = FracCalc.reduce(numerator, denominator, true);
		int actualDenominator = FracCalc.reduce(numerator, denominator, false);
		String actualResult = actualNumerator + "/" + actualDenominator;
		reportResult(numerator + "/" + denominator, expectedResult, actualResult);
	}
    public static void checkpoint1() {
        System.out.println("Starting Checkpoint1 tests:");
        testProduceAnswer("1 * 1/2", "1/2");
        testProduceAnswer("0 + -3/8", "-3/8");
      
    }
    public static void checkpoint2() {
        System.out.println("Starting Checkpoint2 tests:");
        testProduceAnswer("1 * 0_3/8", "3/8");
        testProduceAnswer("0 + 2/3", "2/3");
        testGetUnreducedFractionPart("4", 4, 1);
        testGetUnreducedFractionPart("8/4", 8, 4);
        testGetUnreducedFractionPart("1_1/4", 5, 4);
        testGetUnreducedFractionPart("-2", -2, 1);
        testGetUnreducedFractionPart("-1/2", -1, 2);
        testGetUnreducedFractionPart("0_1/2", 1, 2);
        testGetUnreducedFractionPart("0_0/7", 0, 7);
        testGetUnreducedFractionPart("-1_2/3", -5, 3); // tricky
        testGetUnreducedFractionPart("-0_5/2", -5, 2); // very tricky
    }
    public static void checkpoint3() {
        System.out.println("Starting Checkpoint3 tests:");
        testProduceAnswer("0 + 0_12/16", "3/4");
        testProduceAnswer("1 * -10/15", "-2/3");
        testReduce(2, 3, "2/3");
        testReduce(4, 3, "4/3");
        testReduce(20, 5, "4/1");
        testReduce(3, 24, "1/8");
        testReduce(0, 5, "0/1");
    }
    public static void checkpoint4() {
        System.out.println("Starting Checkpoint4 tests:");
        testProduceAnswer("1_3/8 - 7/14", "7/8");
        testProduceAnswer("3 + -11/5", "4/5");
        testProduceAnswer("-4/3 * 0_1/2", "-2/3");
        testProduceAnswer("2_2/2 / 3_9/4", "4/7");
    }
    public static void finalProject() {
         System.out.println("Starting Final tests:");
         testProduceAnswer("9/8 / -1_1/8", "-1");
         testProduceAnswer("1_2/3 * 4/4", "1_2/3");
         testProduceAnswer("1_7/9 / -4/15", "-6_2/3");
         testProduceAnswer("2/3 + 4/5", "1_7/15");
         testProduceAnswer("-4_5/6 - -1_2/3", "-3_1/6");
         testProduceAnswer("11/2 + -5_1/2", "0");
    }        
    public static void studentTests()
    {
        System.out.println("Starting StudentTests:");
        testProduceAnswer("1 + 1", "2");
        testProduceAnswer("1 + 6/2", "4");
        testProduceAnswer("1/2 - 1", "-1/2");
        testProduceAnswer("-3/5 * -5", "3");
        testProduceAnswer("3/3 / 2/3", "1_1/2");
        testProduceAnswer("0 + 6", "6");
        testProduceAnswer("-1 - -1", "0"); 
        testProduceAnswer("1/10 + 3/5", "7/10");
        testProduceAnswer("-9/3 * -9", "27");
        testProduceAnswer("-1_1/2 + 2_1/4", "3/4");
        testProduceAnswer("5_4/5 / 1/5", "29");
        testProduceAnswer("1 + 6/2", "4");
        testProduceAnswer("0 / 1", "0");
        testProduceAnswer("1_0/3 * 5/2", "2_1/2");
        testProduceAnswer("-0_1/4 - -1/4","0");
        testProduceAnswer("0 + 0", "0");
        testProduceAnswer("-2/2 / -1/2", "2");
        testProduceAnswer("5_5/5 * -1", "-6");
        testProduceAnswer("100 - 0", "100");
        testProduceAnswer("-100 * 0", "0");
        testProduceAnswer("-3_5/4 + 7/4","-2_1/2");
    }
    public static void runTests()
    {
        System.out.println("Starting to run tests:");
        checkpoint1();
        checkpoint2();
        checkpoint3();
        checkpoint4();
        finalProject();
        studentTests();
        System.out.println("Finished running tests.");
    }
}