package fracCalc;
import java.util.Scanner;

public class FracCalc {


	public static int getUnreducedFractionPart(String operand, boolean wantNumerator) {
String top = "";
String bottom = "";
if (operand.indexOf ("/") == -1) {
top = operand + ""; 
		bottom = "1";
}
else if (operand.indexOf ("_") != -1) {
			if (operand.indexOf("-0_") == -1){
				String d = operand.substring (0, operand.indexOf ("_"));
				int i = Integer.parseInt (d);
				String e = operand.substring (operand.indexOf ("_") + 1, operand.indexOf("/"));
				int j = Integer.parseInt (e);
				String f = operand.substring (operand.indexOf ("/") + 1); 
				int k = Integer.parseInt (f);
					if (i < 0){
						top = "-" + (Math.abs(i) * k + j);
					}
					else if (i >= 0) {
						top = i * k + j + ""; 
					}
				bottom = k + "";
			}
			else {
				String e = operand.substring (operand.indexOf ("_") + 1, operand.indexOf("/"));
				int j = Integer.parseInt (e);
				String f = operand.substring (operand.indexOf ("/") + 1); 
				int k = Integer.parseInt (f);
				top = "-" + j;
				bottom = k + "";
			}
}
else {
		top = operand.substring (0, operand.indexOf("/"));
		bottom = operand.substring (operand.indexOf("/")+1);
}
int topp = Integer.parseInt(top);
int bottomm = Integer.parseInt(bottom);
if (wantNumerator == true){
		return topp;
}
else {
		return bottomm;
	}
}
	
	public static int gcd(int a, int b) {
		a = Math.abs(a);
		b = Math.abs(b);
		int max = Math.max(a, b);
		int min = Math.min(a, b);
		while (min != 0) {
			int tmp = min;
			min = max % min;
			max = tmp;
		}
		return max;
	}
	
	public static int reduce(int numerator, int denominator, boolean wantNumerator) {
		int max = gcd (numerator, denominator);
		numerator = numerator / max;
		denominator = denominator / max;
		if (wantNumerator == true) {
			return numerator;
		}
		else {
			return denominator;
		}
	}


	public static String formatAnswer(int numerator, int denominator) {
String a = "";
		if (numerator == 0) {
			a = 0 + "";
		}
		else if (denominator == 1){
			a = numerator + "";
		}
		else if (denominator == numerator){
			a = 1 + "";
		}
		else if (denominator == (-1 * numerator)){
			a = -1 + "";
		}
		else if (Math.abs(numerator) < denominator) {
			a = numerator + "/" + denominator;
		}		
		else if (Math.abs(numerator) > denominator) {
			int whole = numerator / denominator;
			int remainder = Math.abs(numerator) % denominator;
			a = whole + "_" + remainder + "/" + Math.abs(denominator);
			if (whole == -0) {
				a = "-" + remainder + "/" + Math.abs(denominator);
			}
			else if (whole == 0) {
				a = remainder + "/" + Math.abs(denominator);
	}
}	
return a;
}

	public static String produceAnswer(String inputLine) {
		String a = inputLine.substring (0, inputLine.indexOf (" "));
		String b = inputLine.substring (a.length() + 1, (a.length() + 2));
		String c = inputLine.substring (a.length() + 3);
		String f = getUnreducedFractionPart(c, true) + "/" + getUnreducedFractionPart(c, false);
		String n = f.substring (0, f.indexOf ("/"));
		String m = f.substring (n.length() + 1);
		int r = Integer.parseInt (n);
		int t = Integer.parseInt (m);
		int num = reduce (r, t, true);
		int denom = reduce (r, t, false);
		String g = getUnreducedFractionPart(a, true) + "/" + getUnreducedFractionPart(a, false);
		String o = g.substring (0, g.indexOf ("/"));
		String p = g.substring (o.length() + 1);
		int s = Integer.parseInt (o);
		int u = Integer.parseInt (p);
		int numm = reduce (s, u, true);
		int denomm = reduce (s, u, false);
		String h = "";
		if (b.equals("+")) {
			h = (num * denomm + numm * denom) + "/" + denom * denomm;
		}
else if (b.equals("-")) {
			h = (numm * denom - (num * denomm)) + "/" + denom * denomm;
		}
		else if (b.equals("*")) {
			h = num * numm + "/" + denomm * denom;
		}
		else if (b.equals("/")) {
			h = numm * denom + "/" + num * denomm;
		}
		
		String first = h.substring (0, h.indexOf ("/"));
		int one = Integer.parseInt (first);
		String second = h.substring (h.indexOf ("/") + 1);
		int two = Integer.parseInt (second);
		int gone = reduce (one, two, true);
		int gtwo = reduce (one, two, false);
		if (first.indexOf ("-") != -1 && second.indexOf ("-") != -1) {
			gone = -1 * gone;
			gtwo = -1 * gtwo;
		}
h = formatAnswer (gone, gtwo);
return h;
}	


	public static void main(String[] args) {
		Scanner console = new Scanner (System.in);
		String s = console.nextLine ();
		if (s.equals("test")) {
			Tests.runTests();
		}
		else {
			while (! s.equals("quit")) {
				String z = produceAnswer(s);
				System.out.println (z);
				s = console.nextLine();
		     }
}
		
		System.out.println("Bye!");
	}
}